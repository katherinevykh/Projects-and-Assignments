﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KVykhovanets_CPT_185_Final_Project
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public Form1()
        {
            InitializeComponent();
            instance = this;//form 1 is the current instance
        }
        //button 4x4 opens form 2
        private void btnFourbyFour_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
        }
        //button 5x6 opens form 3
        private void btnFiveBySix_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
        }
        //button 6x7 opens form 4
        private void btnSixbySeven_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
        }
        //button 7x8 opens form 5
        private void btnSevenByEight_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KVykhovanets_CPT_185_Final_Project
{
    public partial class Form2 : Form
    {
        public static Form2 instance;
        Random random = new Random();//randomizes the location of the icons

        List<string> icons = new List<string>() // list of icons and assigns their images
        {
            "!", "!", "Q", "Q", "R", "R", "S", "S",
            "T", "T", "'", "'", "|", "|", "%", "%"
        };

        Label firstClicked, secondClicked;//assigns label that will be clicked first and second to check for match

        public Form2()
        {
            InitializeComponent();
            instance = this;// from form 1 to form 3
            AssignIconsToSquares();//calls method to randomize each icon
        }

        private void label_Click(object sender, EventArgs e)//click event
        {
            if (firstClicked != null && secondClicked != null)
            {
                return;
            }

            Label clickedLabel = sender as Label;//converts the sender into the clicked label or stays null

            if (clickedLabel == null)//set to nothing, return
            {
                return;
            }
            if (clickedLabel.ForeColor == Color.Black)//keeps the user from selecting one tile two times
            {
                return;
            }
            if (firstClicked == null)//if the first was clicked..
            {
                firstClicked = clickedLabel;//set it to the clicked tile/label
                firstClicked.ForeColor = Color.Black;//make it black so that you can see the image of the clicked tile
                return;
            }

            secondClicked = clickedLabel;//set it to the second clicked label
            secondClicked.ForeColor = Color.Black;//make it visible

            CheckForWinner();//call method to check if they match

            if (firstClicked.Text == secondClicked.Text)//if they match
            {//make these variables null again
                firstClicked = null;
                secondClicked = null;
            }
            else//if they dont match
            {
                timer.Start();//leaves them on the screen for a few seconds, then calls tick event
            }
        }

        private void CheckForWinner()
        {
            Label label;
            for (int i = 0; i < tlpFourXFour.Controls.Count; i++)
            {
                label = tlpFourXFour.Controls[i] as Label;

                if (label != null && label.ForeColor == label.BackColor)
                {
                    return;
                }
            }
            MessageBox.Show("Congrats. You matched all the tiles!");//after all tiles are matched, display this message
            this.Close();//close form and go back to form 1
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            //flips the labels back overn (makes them invisible again)
            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;
            //makes the clicked label null again
            firstClicked = null;
            secondClicked = null;
        }

        private void AssignIconsToSquares()
        {
            Label label;//stores what label we are looking at
            int randomNumber;//random index in the list of labels

            for (int i = 0; i < tlpFourXFour.Controls.Count; i++)//going through each random label
            {
                if (tlpFourXFour.Controls[i] is Label)//if the index is a label, it is assigned to the square
                {
                    label = (Label)tlpFourXFour.Controls[i];
                }
                else
                {
                    continue;//goes to next thing in the loop
                }

                randomNumber = random.Next(0, icons.Count);//random number will change to a number within the index
                label.Text = icons[randomNumber];//the text on the label will equal the icon assigned to it

                icons.RemoveAt(randomNumber);//removes the number after it is used so that it is not used again
            }
        }
    }
}

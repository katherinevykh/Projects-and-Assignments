﻿namespace KVykhovanets_CPT_185_Final_Project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tlpFiveXSix = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.tlpFiveXSix.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpFiveXSix
            // 
            this.tlpFiveXSix.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpFiveXSix.ColumnCount = 5;
            this.tlpFiveXSix.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFiveXSix.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFiveXSix.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFiveXSix.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFiveXSix.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFiveXSix.Controls.Add(this.label30, 4, 5);
            this.tlpFiveXSix.Controls.Add(this.label29, 3, 5);
            this.tlpFiveXSix.Controls.Add(this.label28, 2, 5);
            this.tlpFiveXSix.Controls.Add(this.label27, 1, 5);
            this.tlpFiveXSix.Controls.Add(this.label26, 0, 5);
            this.tlpFiveXSix.Controls.Add(this.label25, 4, 4);
            this.tlpFiveXSix.Controls.Add(this.label24, 3, 4);
            this.tlpFiveXSix.Controls.Add(this.label23, 2, 4);
            this.tlpFiveXSix.Controls.Add(this.label22, 1, 4);
            this.tlpFiveXSix.Controls.Add(this.label21, 0, 4);
            this.tlpFiveXSix.Controls.Add(this.label20, 4, 3);
            this.tlpFiveXSix.Controls.Add(this.label19, 3, 3);
            this.tlpFiveXSix.Controls.Add(this.label18, 2, 3);
            this.tlpFiveXSix.Controls.Add(this.label17, 1, 3);
            this.tlpFiveXSix.Controls.Add(this.label16, 0, 3);
            this.tlpFiveXSix.Controls.Add(this.label15, 4, 2);
            this.tlpFiveXSix.Controls.Add(this.label14, 3, 2);
            this.tlpFiveXSix.Controls.Add(this.label13, 2, 2);
            this.tlpFiveXSix.Controls.Add(this.label12, 1, 2);
            this.tlpFiveXSix.Controls.Add(this.label11, 0, 2);
            this.tlpFiveXSix.Controls.Add(this.label10, 4, 1);
            this.tlpFiveXSix.Controls.Add(this.label9, 3, 1);
            this.tlpFiveXSix.Controls.Add(this.label8, 2, 1);
            this.tlpFiveXSix.Controls.Add(this.label7, 1, 1);
            this.tlpFiveXSix.Controls.Add(this.label6, 0, 1);
            this.tlpFiveXSix.Controls.Add(this.label5, 4, 0);
            this.tlpFiveXSix.Controls.Add(this.label4, 3, 0);
            this.tlpFiveXSix.Controls.Add(this.label3, 2, 0);
            this.tlpFiveXSix.Controls.Add(this.label2, 1, 0);
            this.tlpFiveXSix.Controls.Add(this.label1, 0, 0);
            this.tlpFiveXSix.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpFiveXSix.Location = new System.Drawing.Point(0, 0);
            this.tlpFiveXSix.Name = "tlpFiveXSix";
            this.tlpFiveXSix.RowCount = 6;
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpFiveXSix.Size = new System.Drawing.Size(574, 591);
            this.tlpFiveXSix.TabIndex = 0;
            // 
            // label30
            // 
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label30.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label30.Location = new System.Drawing.Point(462, 493);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(106, 95);
            this.label30.TabIndex = 29;
            this.label30.Text = "c";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label29
            // 
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label29.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label29.Location = new System.Drawing.Point(348, 493);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 95);
            this.label29.TabIndex = 28;
            this.label29.Text = "c";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label28
            // 
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label28.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label28.Location = new System.Drawing.Point(234, 493);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(105, 95);
            this.label28.TabIndex = 27;
            this.label28.Text = "c";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label27
            // 
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label27.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label27.Location = new System.Drawing.Point(120, 493);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(105, 95);
            this.label27.TabIndex = 26;
            this.label27.Text = "c";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label26
            // 
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label26.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label26.Location = new System.Drawing.Point(6, 493);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(105, 95);
            this.label26.TabIndex = 25;
            this.label26.Text = "c";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label25
            // 
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label25.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label25.Location = new System.Drawing.Point(462, 395);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(106, 95);
            this.label25.TabIndex = 24;
            this.label25.Text = "c";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label24
            // 
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label24.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label24.Location = new System.Drawing.Point(348, 395);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(105, 95);
            this.label24.TabIndex = 23;
            this.label24.Text = "c";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label23.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label23.Location = new System.Drawing.Point(234, 395);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 95);
            this.label23.TabIndex = 22;
            this.label23.Text = "c";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label22.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label22.Location = new System.Drawing.Point(120, 395);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(105, 95);
            this.label22.TabIndex = 21;
            this.label22.Text = "c";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label21
            // 
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label21.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label21.Location = new System.Drawing.Point(6, 395);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 95);
            this.label21.TabIndex = 20;
            this.label21.Text = "c";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label20.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label20.Location = new System.Drawing.Point(462, 297);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 95);
            this.label20.TabIndex = 19;
            this.label20.Text = "c";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label19
            // 
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label19.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label19.Location = new System.Drawing.Point(348, 297);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(105, 95);
            this.label19.TabIndex = 18;
            this.label19.Text = "c";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label18.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label18.Location = new System.Drawing.Point(234, 297);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 95);
            this.label18.TabIndex = 17;
            this.label18.Text = "c";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label17.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label17.Location = new System.Drawing.Point(120, 297);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(105, 95);
            this.label17.TabIndex = 16;
            this.label17.Text = "c";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label16.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label16.Location = new System.Drawing.Point(6, 297);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 95);
            this.label16.TabIndex = 15;
            this.label16.Text = "c";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label15.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label15.Location = new System.Drawing.Point(462, 199);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 95);
            this.label15.TabIndex = 14;
            this.label15.Text = "c";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label14.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label14.Location = new System.Drawing.Point(348, 199);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 95);
            this.label14.TabIndex = 13;
            this.label14.Text = "c";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label13.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label13.Location = new System.Drawing.Point(234, 199);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 95);
            this.label13.TabIndex = 12;
            this.label13.Text = "c";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label12.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label12.Location = new System.Drawing.Point(120, 199);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 95);
            this.label12.TabIndex = 11;
            this.label12.Text = "c";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label11.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label11.Location = new System.Drawing.Point(6, 199);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 95);
            this.label11.TabIndex = 10;
            this.label11.Text = "c";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label10.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label10.Location = new System.Drawing.Point(462, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 95);
            this.label10.TabIndex = 9;
            this.label10.Text = "c";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label9.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label9.Location = new System.Drawing.Point(348, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 95);
            this.label9.TabIndex = 8;
            this.label9.Text = "c";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label8.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label8.Location = new System.Drawing.Point(234, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 95);
            this.label8.TabIndex = 7;
            this.label8.Text = "c";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label7.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label7.Location = new System.Drawing.Point(120, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 95);
            this.label7.TabIndex = 6;
            this.label7.Text = "c";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label6.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label6.Location = new System.Drawing.Point(6, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 95);
            this.label6.TabIndex = 5;
            this.label6.Text = "c";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label5.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label5.Location = new System.Drawing.Point(462, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 95);
            this.label5.TabIndex = 4;
            this.label5.Text = "c";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label4.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label4.Location = new System.Drawing.Point(348, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 95);
            this.label4.TabIndex = 3;
            this.label4.Text = "c";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label3.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label3.Location = new System.Drawing.Point(234, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 95);
            this.label3.TabIndex = 2;
            this.label3.Text = "c";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label2.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label2.Location = new System.Drawing.Point(120, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 95);
            this.label2.TabIndex = 1;
            this.label2.Text = "c";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label_Clicked);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Wingdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 95);
            this.label1.TabIndex = 0;
            this.label1.Text = "c";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label_Clicked);
            // 
            // timer
            // 
            this.timer.Interval = 750;
            this.timer.Tick += new System.EventHandler(this.timer_Tick_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(574, 591);
            this.Controls.Add(this.tlpFiveXSix);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "5x6";
            this.Click += new System.EventHandler(this.label_Click);
            this.tlpFiveXSix.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpFiveXSix;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer;
    }
}
﻿namespace KVykhovanets_CPT_185_Final_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnFourbyFour = new System.Windows.Forms.Button();
            this.btnFiveBySix = new System.Windows.Forms.Button();
            this.btnSixbySeven = new System.Windows.Forms.Button();
            this.btnSevenByEight = new System.Windows.Forms.Button();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(175, 44);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(146, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(249, 46);
            this.label5.TabIndex = 5;
            this.label5.Text = "TILE MATCH!";
            // 
            // btnFourbyFour
            // 
            this.btnFourbyFour.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnFourbyFour.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnFourbyFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFourbyFour.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFourbyFour.Location = new System.Drawing.Point(152, 222);
            this.btnFourbyFour.Margin = new System.Windows.Forms.Padding(4);
            this.btnFourbyFour.Name = "btnFourbyFour";
            this.btnFourbyFour.Size = new System.Drawing.Size(103, 46);
            this.btnFourbyFour.TabIndex = 0;
            this.btnFourbyFour.Text = "4 x 4  (easy) ";
            this.toolTip1.SetToolTip(this.btnFourbyFour, "16 tiles (8 pairs)");
            this.btnFourbyFour.UseVisualStyleBackColor = false;
            this.btnFourbyFour.Click += new System.EventHandler(this.btnFourbyFour_Click);
            // 
            // btnFiveBySix
            // 
            this.btnFiveBySix.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnFiveBySix.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnFiveBySix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFiveBySix.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFiveBySix.Location = new System.Drawing.Point(285, 222);
            this.btnFiveBySix.Margin = new System.Windows.Forms.Padding(4);
            this.btnFiveBySix.Name = "btnFiveBySix";
            this.btnFiveBySix.Size = new System.Drawing.Size(103, 46);
            this.btnFiveBySix.TabIndex = 1;
            this.btnFiveBySix.Text = "5 x 6 (med-easy)";
            this.toolTip1.SetToolTip(this.btnFiveBySix, "30 tiles (15 pairs)");
            this.btnFiveBySix.UseVisualStyleBackColor = false;
            this.btnFiveBySix.Click += new System.EventHandler(this.btnFiveBySix_Click);
            // 
            // btnSixbySeven
            // 
            this.btnSixbySeven.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSixbySeven.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnSixbySeven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSixbySeven.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSixbySeven.Location = new System.Drawing.Point(152, 299);
            this.btnSixbySeven.Margin = new System.Windows.Forms.Padding(4);
            this.btnSixbySeven.Name = "btnSixbySeven";
            this.btnSixbySeven.Size = new System.Drawing.Size(103, 46);
            this.btnSixbySeven.TabIndex = 2;
            this.btnSixbySeven.Text = "6 x 7 (med-hard)";
            this.toolTip1.SetToolTip(this.btnSixbySeven, "42 tiles (21 pairs)");
            this.btnSixbySeven.UseVisualStyleBackColor = false;
            this.btnSixbySeven.Click += new System.EventHandler(this.btnSixbySeven_Click);
            // 
            // btnSevenByEight
            // 
            this.btnSevenByEight.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSevenByEight.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnSevenByEight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSevenByEight.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSevenByEight.Location = new System.Drawing.Point(285, 299);
            this.btnSevenByEight.Margin = new System.Windows.Forms.Padding(4);
            this.btnSevenByEight.Name = "btnSevenByEight";
            this.btnSevenByEight.Size = new System.Drawing.Size(103, 46);
            this.btnSevenByEight.TabIndex = 3;
            this.btnSevenByEight.Text = "7 x 8  (hard) ";
            this.toolTip1.SetToolTip(this.btnSevenByEight, "56 tiles (28 pairs)");
            this.btnSevenByEight.UseVisualStyleBackColor = false;
            this.btnSevenByEight.Click += new System.EventHandler(this.btnSevenByEight_Click);
            // 
            // lblInstructions
            // 
            this.lblInstructions.Location = new System.Drawing.Point(99, 152);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(349, 42);
            this.lblInstructions.TabIndex = 13;
            this.lblInstructions.Text = "Please choose one of the difficulty levels below. The goal is to match each pair " +
    "of tiles. ";
            this.lblInstructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(570, 419);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.btnSevenByEight);
            this.Controls.Add(this.btnSixbySeven);
            this.Controls.Add(this.btnFiveBySix);
            this.Controls.Add(this.btnFourbyFour);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tile Match!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnFourbyFour;
        private System.Windows.Forms.Button btnFiveBySix;
        private System.Windows.Forms.Button btnSixbySeven;
        private System.Windows.Forms.Button btnSevenByEight;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

